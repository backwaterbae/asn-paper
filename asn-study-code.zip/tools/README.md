# Acquisition tools

Two Python scripts that collect public internet-registry and routing data as evidence: raw responses saved exactly as received, hashed at capture, and logged for chain of custody. They are the tools cited in Appendix A of the paper.

| Script | Version | SHA-256 | What it answers |
|---|---|---|---|
| `bkbn_ip_origin_pull.py` | 1.2 | `9d9028c79e182dcbc42279ecc039fca05f8bf74004f150af45be655d0ad2a8c4` | Who registered an IP address, and which network was announcing it **on the date it was observed** |
| `bkbn_longitudinal_pull.py` | 1.3 | `86f50095a0325f149a44e7980ebe25a44f0ba733aeabf7411a4067bdd903e9dd` | One observation window over a cohort of ASNs (announced prefixes, visibility, neighbours, registry records, RPKI), plus change reports between windows |

`BSP-BKBN-ASN-cohort.json` is the cohort used with the longitudinal tool: the paper's 24 ASNs and its watch prefixes. Three prefixes are deliberately left as `FILL-ME-…` placeholders; the tool skips them and says so.

---

## Requirements

- Python 3.8 or later, **standard library only**. Runs on stock macOS `python3` and on Linux.
- Network access to the public endpoints listed under *Data sources*.
- No API keys and no accounts.

## Verify before you run

```bash
shasum -a 256 bkbn_ip_origin_pull.py bkbn_longitudinal_pull.py
```

Compare the output with the table above (or with `SHA256SUMS` at the repository root). Every evidence file a tool writes records the tool's own hash in its sidecar, so a run can always be traced back to the exact code that produced it.

## Try it offline first

Both tools have a `--mock` mode. It uses built-in sample responses, makes no network calls, and labels every file it writes `MOCK` / `Src-MOCK`, so mock output can never be mistaken for evidence.

```bash
python3 bkbn_ip_origin_pull.py --ip 192.0.2.10@2026-07-25 --mock --outdir ./mock-test
python3 bkbn_longitudinal_pull.py run --cohort BSP-BKBN-ASN-cohort.json --mock --outdir ./mock-test
```

---

## `bkbn_ip_origin_pull.py`

For each address, at a stated observation date:

1. **IANA RDAP bootstrap**, to pick the regional registry responsible for the address (this avoids ARIN's referral placeholders for RIPE, APNIC, AFRINIC and LACNIC space).
2. **That registry's RDAP record** for the address: the registrant.
3. **RIPEstat `network-info`:** the covering prefix and origin ASN today.
4. **RIPEstat `routing-history`** over the observation date ± `--window-days`. **Only prefixes that cover the address are counted.** If the address is unrouted today, the query falls back to the registry's registered block, so a historical announcement can still be found.
5. **RDAP for every origin ASN found:** the network's registered holder.

```bash
python3 bkbn_ip_origin_pull.py --ip 123.150.3.39@2026-07-25 --ip 145.74.110.172@2026-07-25
```

| Option | Default | Meaning |
|---|---|---|
| `--ip ADDRESS@YYYY-MM-DD` | required, repeatable | Address and the date it was observed (IPv4 or IPv6) |
| `--window-days N` | 3 | Days either side of the observation date |
| `--flag-asn N` | 7046 | ASN to report a yes/no against at observation time |
| `--outdir DIR` | `~/Claude/CASE-INTEL/Cases/BSP-BKBN-ASN` | Case folder (`CASE_INTEL_HOME` overrides the root) |
| `--delay S` | 1.0 | Seconds between live requests |
| `--mock` | off | Offline self-test |

> **Shell note:** type real values. In examples, anything written as `<like-this>` is a placeholder; zsh and bash treat a bare `<` as a file redirect.

**Reading the result:** use *origin at observation*, not *origin now*. An empty origin means no announcement covering the address appeared in RIPEstat's collectors during the window: the address was unrouted, as far as RIS could see.

## `bkbn_longitudinal_pull.py`

```bash
# one observation window (add --history once, to backfill routing history)
python3 bkbn_longitudinal_pull.py run --cohort BSP-BKBN-ASN-cohort.json [--history]

# limit to particular ASNs
python3 bkbn_longitudinal_pull.py run --cohort BSP-BKBN-ASN-cohort.json --asn 7046 --asn 7015

# change report between two windows (derived analysis)
python3 bkbn_longitudinal_pull.py diff --old RUN-A/RUN-A_manifest.json --new RUN-B/RUN-B_manifest.json
```

Per run: IANA bootstraps; for each cohort ASN, RIR RDAP `autnum`, RIPEstat `announced-prefixes`, `routing-status` and `asn-neighbours` (plus `routing-history` with `--history`); for each watch prefix, RIR RDAP `ip` and RIPEstat `rpki-validation`.

The `diff` report checks the **control arm first**. If a control ASN lost visibility between the two windows, it flags an *instrument event candidate*: verify the monitoring (ideally with a second collector) before treating any change in that window as real. That rule exists because of the paper's Section 4.4.

**Cohort format** (`BSP-BKBN-ASN-cohort.json`): `asns` is a list of `{asn, entity, paper_status, arm}`, where `arm` is `anomalous`, `lead`, `unresolved` or `control`. `watch_prefixes` is a list of `{prefix, label, checks, expect_origin_asn}`.

---

## What gets written

```
<case folder>/
  BSP-BKBN-ASN_FILE_HASHES.txt        SHA-256 of every file, appended per run
  BSP-BKBN-ASN_custody.csv            one row per acquisition
  IPORIGIN-<UTC stamp>/  or  RUN-<UTC stamp>/
    BSP-BKBN-ASN-PND-<date>_<SOURCE>-<ARTIFACT>_<target>_<HHMMSSZ>.json        raw response, byte for byte
    BSP-BKBN-ASN-PND-<date>_<SOURCE>-<ARTIFACT>_<target>_<HHMMSSZ>.json.meta.json   sidecar
    …_manifest.json, …summary.md      derived analysis (bkbn_ip_origin_pull.py logs these as DERIVED in the hash file;
                                       bkbn_longitudinal_pull.py logs its manifest in the custody CSV)
```

- **Raw files are the evidence.** They are never parsed and rewritten, and never overwritten (a name collision gets a `.v2` suffix).
- **Sidecars** record the request and final URLs, UTC request and response times, HTTP status, key headers including the server `Date`, how the endpoint was chosen, the tool name, version and SHA-256, the acquiring user and host, and the raw file's SHA-256.
- **Non-200 responses are saved too.** A 404 or 429 is a record of what the server said. Those files carry the `ANO` code instead of `PND`.
- **Source tier** is assigned from the exact responding host: `Src-R` for IANA and the regional registries, `Src-S` for RIPEstat.
- Summaries and manifests are **derived analysis**: convenient to read, but conclusions rest on the raw files they cite.
- Evidence writing never depends on the console, so piping output into `head` won't cut a run short.

To check a run later:

```bash
cd <case folder>
grep -v DERIVED BSP-BKBN-ASN_FILE_HASHES.txt | shasum -a 256 -c -
```

## Data sources

| Endpoint | Operator | Tier |
|---|---|---|
| `data.iana.org/rdap/*.json` | IANA | Src-R |
| `rdap.arin.net`, `rdap.db.ripe.net`, `rdap.apnic.net`, `rdap.afrinic.net`, `rdap.lacnic.net` | Regional Internet Registries | Src-R |
| `stat.ripe.net/data/*` | RIPE NCC (RIPEstat, RIS collectors) | Src-S |

Requests identify themselves with a descriptive User-Agent and `sourceapp=bwf-bkbn`, and are spaced one second apart by default. Please keep that courtesy if you adapt the tools.

## Operational security

Every query goes to a neutral public registry or aggregator. **Nothing here contacts the infrastructure being investigated:** no DNS queries to its nameservers, no HTTP to its hosts, no port checks. That makes the tools safe to run from an ordinary workstation. Anything that *does* touch subject infrastructure belongs in an isolated environment and is outside these tools by design.

## Known limits

- **RIS is a sample.** RIPEstat sees the global routing table through several hundred peers. An announcement that never reached them (for example, one with deliberately narrow scope) would not appear.
- **History windows are coarse.** `routing-history` timelines are time ranges; a sub-hour announcement can fall between them.
- **Registry records change.** RDAP returns the record as of the query, not as of the observation date. The registration and last-changed events in the raw file show how recent it is.
- **No passive DNS.** Neither tool queries passive-DNS providers. Hostname-to-address evidence in the paper came from a separate pipeline.
- **Version history:** `bkbn_ip_origin_pull.py` v1.0 counted origins of more-specific prefixes that did not cover the address, and skipped the history query for unrouted addresses. v1.1 fixed both; v1.2 changes only the default folder. Results produced under v1.0 were re-derived from their raw files under the v1.1 logic.

## License

The scripts are released under the MIT License (see `LICENSE` at the repository root). The paper is licensed separately (see `LICENSE-PAPER.md`).
