# License for the paper

**How Unassigned Addressing Created a New Attack Vector: An Analysis of Dormant Autonomous System Exploitation in Backbone Internet Infrastructure**
© 2026 Lu Anne Gammage (Esposito), Backwater Forensics

The paper and its web edition (`paper/` and `web/`) are licensed under the
**Creative Commons Attribution 4.0 International License (CC BY 4.0)**.

You may share and adapt the material for any purpose, provided you give appropriate
credit, link to the license, and indicate if changes were made.

- Summary: https://creativecommons.org/licenses/by/4.0/
- Full legal code: https://creativecommons.org/licenses/by/4.0/legalcode

**Suggested attribution:** Gammage (Esposito), L. A. (2026). *How unassigned addressing
created a new attack vector* (Revised 2026-10-20). Backwater Forensics. Licensed under CC BY 4.0.

Registry and routing data quoted in the paper (ARIN, RIPE NCC, APNIC, AFRINIC, LACNIC,
IANA, RIPEstat) remain subject to their providers' own terms of use.

The code in `tools/` and `build/` is licensed separately under the MIT License (`LICENSE`).
